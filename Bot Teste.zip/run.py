from dotenv import load_dotenv


load_dotenv() 

from src import main


if __name__ == "__main__": 
    main()          